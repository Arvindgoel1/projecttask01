<?php
	require ("layout.php");
	page_head();
	if(isset($_REQUEST["add_submit"]))
	{
		$q = "INSERT INTO groups(`grp_name`,`grp_desc`,`grp_addon`,`grp_status`) VALUES('".$_REQUEST["grp_name"]."','".$_REQUEST["grp_desc"]."',Now(),1)";
		$r = db_query($q);
		if($r == true)
		{
			echo "<script>alert('Add successfully.');window.history.back();</script>";
		}
		else 	
		{
			echo "<script>alert('Internal error! Try again.');window.history.back();</script>";
		}		
	}
	else if(isset($_REQUEST["edit_submit"]) && isset($_REQUEST["edit_eid"]))
	{
		$q = "UPDATE groups SET grp_name = '".$_REQUEST["grp_name"]."',grp_desc = '".$_REQUEST["grp_desc"]."' WHERE grp_id = '".$_REQUEST["edit_eid"]."'";
		$r = db_query($q);
		if($r == true)
		{
			echo "<script>alert('Update successfully.');window.location.href='group.php';</script>";
		}
		else 	
		{
			echo "<script>alert('Internal error! Try again.');window.history.back();</script>";
		}
	}
	else if(isset($_REQUEST["status_eid"]))
	{
		$q = "UPDATE groups SET grp_status = '".$_REQUEST["status"]."' WHERE grp_id = '".$_REQUEST["status_eid"]."'";
		$r = db_query($q);
		if($r == true)
		{
			echo "<script>alert('Update successfully.');window.location.href='group.php';</script>";
		}
		else 	
		{
			echo "<script>alert('Internal error! Try again.');window.history.back();</script>";
		}
	}
	else
	{
		?>
		<body>
			<div class="container">
			 	<div class="row">
				 	<div class="col col-md-12">
						<?php menu();?>
				 	</div>
				</div>

				<div class="row">
					<div class="col col-md-12">
						<h2 class="pull-left">Groups</h2>						
						<div class="pull-right">
							<button type="button" class="btn btn-sm btn-danger pull-right" title="Go Back" onclick="window.history.back()"><i class="fa fa-arrow-left" style="margin: 0px;"></i></button>
							
							<button type="button" id="add_form_btn" class="btn btn-sm btn-info pull-right" title="Add New" style="margin-right:10px;"><i class="fa fa-plus" style="margin: 0px;"></i></button>
						</div>
					</div>
				</div>
			</div>

			<!-- start add form -->
			<div id="add_form_wrap">	
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="title text-center">
								<hr>
									<h3>Add Form</h3>
								<hr>
							</div>
							<form action="group.php" method="post">
								<div class="row">
									<div class="col col-md-6">
										<div class="form-group">
											<label>Name</label>
											<input type="text" name="grp_name" maxlength="500" class="form-control" required="" placeholder="group name">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col col-md-12">
										<div class="form-group">
											<label>Description</label>
											<textarea name="grp_desc" rows="5" maxlength="1000" class="form-control" placeholder="group description"></textarea>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col col-md-12">
										<div class="form-group text-center">
											<button type="submit" name="add_submit" class="btn btn-sm btn-primary">Submit</button>
											&nbsp;&nbsp;
											<button type="reset" class="btn btn-sm btn-danger">Reset</button>
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>	
				</div>
			</div>
			<!-- end add form -->
			
			<!-- start edit form -->
			<?php
				if(isset($_REQUEST["edit"]) && isset($_REQUEST["edit_id"]))
				{
					$q = "SELECT * FROM groups WHERE grp_id = '".$_REQUEST["edit_id"]."'";
					$d = mysqli_fetch_assoc(db_query($q)); 
					?>
						<div id="edit_form_wrap">
							<div class="container">
								<div class="row">
									<div class="col-md-12">
										<div class="title text-center">
											<hr>
												<h3>Edit Form</h3>
											<hr>
										</div>
										<form action="group.php" method="post">
											<div class="row">
												<div class="col col-md-6">
													<div class="form-group">
														<label>Name</label>
														<input type="text" name="grp_name" maxlength="500" class="form-control" required="" placeholder="place name" value="<?php echo $d['grp_name'];?>">
														<input type="hidden" name="edit_eid" value="<?php echo $_REQUEST["edit_id"];?>">
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col col-md-12">
													<div class="form-group">
														<label>Description</label>
														<textarea name="grp_desc" rows="5" maxlength="1000" class="form-control" placeholder="place description"><?php echo $d['grp_desc'];?></textarea>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col col-md-12">
													<div class="form-group text-center">
														<button type="submit" name="edit_submit" class="btn btn-sm btn-primary">Submit</button>
														&nbsp;&nbsp;
														<button type="reset" class="btn btn-sm btn-danger">Reset</button>
													</div>
												</div>
											</div>
										</form>
									</div>
								</div>
							</div>	
						</div>
					<?php
				}
			?>
			<!-- end edit form -->

			<div class="container">
				<div class="row">
					<div class="col-md-12">								
						<?php 
							$q = "SELECT * FROM groups ORDER BY grp_id DESC";
							$r = db_query($q);
						?> 
						<div class="table-responsive">                               
							<table class="table table-striped table-hover view_table">
								<thead>
									<tr>
										<th>Sr No.</th>
										<th>Name</th>
										<th>Description</th>
										<th>Status</th>
										<th>Student</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php
										$sr = 0;
										while($d = mysqli_fetch_array($r))
										{
											$sr++;
											?>
												<tr>
													<td>                                                           
														<?php echo $sr; ?>             
													</td>
													<td>                                                           
														<?php echo $d["grp_name"]; ?>             
													</td>
													<td>                                                           
														<?php echo $d["grp_desc"]; ?>             
													</td>
													<td>                                                            
														<?php 
															if($d["grp_status"]==1)
															{
																?>
																	<a href="group.php?status_eid=<?php echo $d["grp_id"]?>&status=0">
																		<button class="btn w-33 btn-sm btn-primary mt-1 mr-1 act_btn">Active</button>
																	</a>
																<?php
															}
															else
															{
																?>
																	<a href="group.php?status_eid=<?php echo $d["grp_id"]?>&status=1">
																		<button class="btn w-33 btn-sm btn-danger mt-1 mr-1 act_btn">Inactive</button>
																	</a>
																<?php 
															}
														?>             
													</td>
													<td>  
														<?php
															$q1 = "SELECT std_id FROM student WHERE std_grpid = '".$d["grp_id"]."'";
															$r1 = db_query($q1);
														?>
														<a href="#">
															<button class="btn w-33 btn-sm btn-success mt-1 mr-1 act_btn">View  <span class="badge"><?php echo mysqli_num_rows($r1);?></span></button>
														</a>
													</td>
													<td>  
														<a href="group.php?edit=true&edit_id=<?php echo $d['grp_id']?>">
															<button class="btn w-33 btn-sm btn-warning mt-1 mr-1 act_btn">Edit</button>
														</a>
													</td>
												</tr>
											<?php
										}
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
			<?php footer();?> 
			<script type="text/javascript">
				$(document).ready(function() 
				{

				    $("#add_form_wrap").hide();
				    $("#add_form_btn").click(function()
			    	{
			    		$("#add_form_wrap").slideToggle(200);
			    	});
				});
			</script>             
		</body>
		</html>
		<?php
	}
?>