-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 06, 2020 at 01:23 PM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `group`
--

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `grp_id` int(11) NOT NULL AUTO_INCREMENT,
  `grp_name` varchar(500) NOT NULL,
  `grp_desc` varchar(1000) NOT NULL,
  `grp_addon` timestamp NOT NULL,
  `grp_status` int(2) NOT NULL,
  PRIMARY KEY (`grp_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`grp_id`, `grp_name`, `grp_desc`, `grp_addon`, `grp_status`) VALUES
(1, 'Group 1', 'Test Description ', '2020-01-06 12:55:44', 1),
(2, 'Mumbai Indians', 'IPL', '2020-01-06 12:57:10', 1);

-- --------------------------------------------------------

--
-- Table structure for table `std_to_grp`
--

DROP TABLE IF EXISTS `std_to_grp`;
CREATE TABLE IF NOT EXISTS `std_to_grp` (
  `stdgrp_id` int(11) NOT NULL AUTO_INCREMENT,
  `stdgrp_grpid` int(11) NOT NULL,
  `stdgrp_stdid` int(11) NOT NULL,
  `stdgrp_addon` timestamp NOT NULL,
  PRIMARY KEY (`stdgrp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `std_id` int(11) NOT NULL AUTO_INCREMENT,
  `std_name` varchar(500) NOT NULL,
  `std_mobile` varchar(100) NOT NULL,
  `std_grpid` int(11) NOT NULL,
  `std_addon` timestamp NOT NULL,
  `std_status` int(2) NOT NULL,
  PRIMARY KEY (`std_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`std_id`, `std_name`, `std_mobile`, `std_grpid`, `std_addon`, `std_status`) VALUES
(1, 'ROMI YADAV', '8521478541', 2, '2020-01-06 13:03:39', 1),
(2, ' KRISHNA NARAYAN', '9856478541', 2, '2020-01-06 13:04:33', 1),
(3, 'Vipin Chauhan', '8547412563', 1, '0000-00-00 00:00:00', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
