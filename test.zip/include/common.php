<?php
	function group_det($id,$field)
	{
		$query = "SELECT ".$field." FROM groups WHERE grp_id='".$id."'";
		$result = db_query($query);
		$data = mysqli_fetch_assoc($result);
		return $data[$field];

	}
?>