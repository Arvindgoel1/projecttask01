<?php
  require ("layout.php");
  page_head();
?>
<body>
  <div class="container">
    <?php menu();?>

    <?php footer();?>
  </div>
</body>
</html>
