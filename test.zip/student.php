<?php
	require ("layout.php");
	page_head();
	if(isset($_REQUEST["add_submit"]))
	{
		$cq = "SELECT std_id FROM student WHERE std_mobile = '".$_REQUEST["std_mobile"]."'";
		$cr = db_query($cq);
		if(mysqli_num_rows($cr)>0)
		{
			echo "<script>alert('Error! Mobile $_REQUEST[std_mobile] already exist.');window.history.back();</script>";
		}	
		else
		{
			$q = "INSERT INTO student(`std_name`,`std_mobile`,`std_addon`,std_grpid,`std_status`) VALUES('".$_REQUEST["std_name"]."','".$_REQUEST["std_mobile"]."','".$_REQUEST["std_grpid"]."',Now(),1)";
			$r = db_query($q);
			if($r == true)
			{
				echo "<script>alert('Add successfully.');window.history.back();</script>";
			}
			else 	
			{
				echo "<script>alert('Internal error! Try again.');window.history.back();</script>";
			}	
		}
	}
	else if(isset($_REQUEST["edit_submit"]) && isset($_REQUEST["edit_eid"]))
	{
		$q = "UPDATE student SET std_name = '".$_REQUEST["std_name"]."',std_mobile = '".$_REQUEST["std_mobile"]."',std_grpid = '".$_REQUEST["std_grpid"]."' WHERE std_id = '".$_REQUEST["edit_eid"]."'";
		$r = db_query($q);
		if($r == true)
		{
			echo "<script>alert('Update successfully.');window.location.href='student.php';</script>";
		}
		else 	
		{
			echo "<script>alert('Internal error! Try again.');window.history.back();</script>";
		}
	}
	else if(isset($_REQUEST["status_eid"]))
	{
		$q = "UPDATE student SET std_status = '".$_REQUEST["status"]."' WHERE std_id = '".$_REQUEST["status_eid"]."'";
		$r = db_query($q);
		if($r == true)
		{
			echo "<script>alert('Update successfully.');window.location.href='student.php';</script>";
		}
		else 	
		{
			echo "<script>alert('Internal error! Try again.');window.history.back();</script>";
		}
	}
	else
	{
		?>
		<body>
			<div class="container">
			 	<div class="row">
				 	<div class="col col-md-12">
						<?php menu();?>
				 	</div>
				</div>

				<div class="row">
					<div class="col col-md-12">
						<h2 class="pull-left">Students</h2>						
						<div class="pull-right">
							<button type="button" class="btn btn-sm btn-danger pull-right" title="Go Back" onclick="window.history.back()"><i class="fa fa-arrow-left" style="margin: 0px;"></i></button>
							
							<button type="button" id="add_form_btn" class="btn btn-sm btn-info pull-right" title="Add New" style="margin-right:10px;"><i class="fa fa-plus" style="margin: 0px;"></i></button>
						</div>
					</div>
				</div>
			</div>

			<!-- start add form -->
			<div id="add_form_wrap">	
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="title text-center">
								<hr>
									<h3>Add Form</h3>
								<hr>
							</div>
							<form action="student.php" method="post">
								<div class="row">
									<div class="col col-md-4">
										<div class="form-group">
											<label>Name</label>
											<input type="text" name="std_name" maxlength="500" class="form-control" required="" placeholder="student name">
										</div>
									</div>
									<div class="col col-md-4">
										<div class="form-group">
											<label>Mobile</label>
											<input type="text" name="std_mobile" maxlength="10"  minlength="10" class="form-control" required="" placeholder="student mobile">
										</div>
									</div>
									<div class="col col-md-4">
										<div class="form-group">
											<label>Group</label>
											<select required="" name="std_grpid" class="form-control">
												<option value="">Select</option>
												<?php 
													$q1 = "SELECT * FROM groups WHERE grp_status = 1 ORDER BY grp_id DESC";
													$r1 = db_query($q1);
													while($d1 = mysqli_fetch_assoc($r1))
													{
														?>
															<option value="<?php echo $d1['grp_id'];?>"><?php echo $d1['grp_name'];?></option>
														<?php
													}
												?> 
											</select>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col col-md-12">
										<div class="form-group text-center">
											<button type="submit" name="add_submit" class="btn btn-sm btn-primary">Submit</button>
											&nbsp;&nbsp;
											<button type="reset" class="btn btn-sm btn-danger">Reset</button>
										</div>
										<hr>
									</div>
								</div>
							</form>
						</div>
					</div>	
				</div>
			</div>
			<!-- end add form -->
			
			<!-- start edit form -->
			<?php
				if(isset($_REQUEST["edit"]) && isset($_REQUEST["edit_id"]))
				{
					$q = "SELECT * FROM student WHERE std_id = '".$_REQUEST["edit_id"]."'";
					$d = mysqli_fetch_assoc(db_query($q)); 
					?>
						<div id="edit_form_wrap">
							<div class="container">
								<div class="row">
									<div class="col-md-12">
										<div class="title text-center">
											<hr>
												<h3>Edit Form</h3>
											<hr>
										</div>
										<form action="student.php" method="post">
											<div class="row">
												<div class="col col-md-4">
													<div class="form-group">
														<label>Name</label>
														<input type="text" name="std_name" maxlength="500" class="form-control" required="" placeholder="place name" value="<?php echo $d['std_name'];?>">
														<input type="hidden" name="edit_eid" value="<?php echo $_REQUEST["edit_id"];?>">
													</div>
												</div>
												<div class="col col-md-4">
													<div class="form-group">
														<label>Mobile</label>
														<input type="text" value="<?php echo $d['std_mobile'];?>" name="std_mobile" maxlength="10"  minlength="10" class="form-control" required="" placeholder="student mobile">
													</div>
												</div>
												<div class="col col-md-4">
													<div class="form-group">
														<label>Group</label>
														<select required="" name="std_grpid" class="form-control">
															<option value="">Select</option>
															<?php 
																$q1 = "SELECT * FROM groups WHERE grp_status = 1 ORDER BY grp_id DESC";
																$r1 = db_query($q1);
																while($d1 = mysqli_fetch_assoc($r1))
																{
																	?>
																		<option <?php if($d["std_grpid"] == $d1["grp_id"]){ echo "selected";}?> value="<?php echo $d1['grp_id'];?>"><?php echo $d1['grp_name'];?></option>
																	<?php
																}
															?> 
														</select>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col col-md-12">
													<div class="form-group text-center">
														<button type="submit" name="edit_submit" class="btn btn-sm btn-primary">Submit</button>
														&nbsp;&nbsp;
														<button type="reset" class="btn btn-sm btn-danger">Reset</button>
													</div>
												</div>
											</div>
										</form>
									</div>
								</div>
							</div>	
						</div>
					<?php
				}
			?>
			<!-- end edit form -->

			<div class="container">
				<div class="row">
					<div class="col-md-12">								
						<?php 
							$q = "SELECT * FROM student ORDER BY std_id DESC";
							$r = db_query($q);
						?> 
						<div class="table-responsive">                               
							<table class="table table-striped table-hover view_table">
								<thead>
									<tr>
										<th>Sr No.</th>
										<th>Name</th>
										<th>Mobile</th>
										<th>Group</th>
										<th>Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php
										$sr = 0;
										while($d = mysqli_fetch_array($r))
										{
											$sr++;
											?>
												<tr>
													<td>                                                           
														<?php echo $sr; ?>             
													</td>
													<td>                                                           
														<?php echo $d["std_name"]; ?>             
													</td>
													<td>                                                           
														<?php echo $d["std_mobile"]; ?>             
													</td>
													<td>                                                           
														<?php echo group_det($d["std_grpid"],"grp_name"); ?>             
													</td>
													<td>                                                            
														<?php 
															if($d["std_status"]==1)
															{
																?>
																	<a href="student.php?status_eid=<?php echo $d["std_id"]?>&status=0">
																		<button class="btn w-33 btn-sm btn-primary mt-1 mr-1 act_btn">Active</button>
																	</a>
																<?php
															}
															else
															{
																?>
																	<a href="student.php?status_eid=<?php echo $d["std_id"]?>&status=1">
																		<button class="btn w-33 btn-sm btn-danger mt-1 mr-1 act_btn">Inactive</button>
																	</a>
																<?php 
															}
														?>             
													</td>
													<td>  
														<a href="student.php?edit=true&edit_id=<?php echo $d['std_id']?>">
															<button class="btn w-33 btn-sm btn-warning mt-1 mr-1 act_btn">Edit</button>
														</a>
													</td>
												</tr>
											<?php
										}
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
			<?php footer();?> 
			<script type="text/javascript">
				$(document).ready(function() 
				{

				    $("#add_form_wrap").hide();
				    $("#add_form_btn").click(function()
			    	{
			    		$("#add_form_wrap").slideToggle(200);
			    	});
				});
			</script>             
		</body>
		</html>
		<?php
	}
?>